package mayorigual;

public class Division {

	public static void main(String[] args) {
	 
	int num1;
	int num2;
	int resultado;
	
	num1 = 234;
	num2 = 0;
	
	if (num2 == 0 ) {
		
	System.out.println("no se puede hacer la cuenta" );	
	}
	
	else {
	
	resultado = num1 / num2;
	
	System.out.println("la division es: "+ resultado);
	
	}
	
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
