package mayorigual;

public class Numeros {

	public static void main(String[] args) {
	//cracion de variable
	int num1;
	int num2;
	
	//asignacion
	num1 = 123;
	num2 = 12;
	
	
	if(num1 > num2) {
		
	System.out.println("el mayor es: " + num1 );
	
	}
	
	else {
		
	     if(num2 > num1) {	
		
		System.out.println("el mayor es: "+ num2);	
		
	}
	     
	     else {
	    	 
	     System.out.println("son iguales");
	     	     
	     }
	     }
	     
	     
		
		
		
		
	}

}
