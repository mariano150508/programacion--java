package mayormenor;

public class NumeroMayor {

	public static void main(String[] args) {
	//Declaracion de variables
	int numeroUno;
	int numeroDos;
	
	//Asignacion a variables
	numeroUno = 19;
	numeroDos = 19;
	
	if(numeroUno > numeroDos) {
		
		System.out.println("el mayor es: " + numeroUno);
		
    }else{
    	
    	if(numeroDos > numeroUno) {
    		
    		System.out.println("el mayor es: " + numeroDos);
    		
    	}else{
    		
    		System.out.println("Ambos numeros son iguales");
    		
    	}
    		
    	
    }

	}

}
