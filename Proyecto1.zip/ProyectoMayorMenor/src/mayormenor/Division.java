package mayormenor;

public class Division {

	public static void main(String[] args) {
		 //Declaracion de variable
		 int numero1;
		 int numero2;
		 int resultado;
		 
		 //Asignacion de variables
		 numero1 = 20;
		 numero2 = 10;
		 
		 if(numero2 == 0) {
			 
			 System.out.println("No es posible realizar la division");
			 
		 }else{
			 
			//Calculo de la division
			 resultado = numero1 / numero2;
			 
			 System.out.println("el resultado de la division es: " + resultado);
			 
		 }
		 
		  
				 
		

	}

}
